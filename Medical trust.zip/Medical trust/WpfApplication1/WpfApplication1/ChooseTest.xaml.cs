﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for ChooseTest.xaml
    /// </summary>
    public partial class ChooseTest : Window
    {
        public ChooseTest()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            /*Vision_Test vs = new Vision_Test();
            vs.Show();*/
            Consigne co = new Consigne(1);
            co.Show();
            this.Close();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Near_Vision_Test ns = new Near_Vision_Test();
            ns.Show();
            Close();
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {

        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {

        }

        private void button5_Click(object sender, RoutedEventArgs e)
        {
            Choice ch = new Choice();
            ch.Show();
            Close();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void button5_Click_1(object sender, RoutedEventArgs e)
        {
            Choice ch = new Choice();
            ch.Show();
            Close();
        }
    }
}
