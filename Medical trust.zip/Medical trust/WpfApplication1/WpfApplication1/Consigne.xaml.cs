﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for Consigne.xaml
    /// </summary>
    public partial class Consigne : Window
    {
        int i;
        public Consigne(int j)
        {
            i = j;
            InitializeComponent();
            Affichage(j);
        }
        void Affichage(int i)
        {
            if(i==1)//test vision de loin
            {
                textBlock1.Text = "\r\n -Place you exactly 3 meters from the screen,\r\n \r\n -With the palm of the hand Right folded shell, hide the right eye without pressing your eyelids";
            }
            else
            {
                if(i==2) textBlock1.Text = "\r\n -Keep your position at 3 meters of the screen,\r\n \r\n -With the palm Left folded shell, hide the left eye pressing your eyelids";
            }
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if(i==1)
            {
                Vision_Test ts = new Vision_Test();
                ts.Show();
                Close();
            }
            else
            {
                if(i==2)
                {
                    Vision_Test2 ts2 = new Vision_Test2();
                    ts2.Show();
                    Close();
                }


            }
            
        }
    }
}
