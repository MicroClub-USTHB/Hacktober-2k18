﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for Vision_Test2.xaml
    /// </summary>
    public partial class Vision_Test2 : Window
    {
        System.Windows.Threading.DispatcherTimer Tr = new System.Windows.Threading.DispatcherTimer();
        string[] Chemin_img;
        public Vision_Test2()
        {
            InitializeComponent();
            Tr.Interval = new TimeSpan(5000);
            Tr.Tick += new EventHandler(dispatcherTimer_Tick);
            Chemin_img = new string[20];

            Chemin_img[0] = Directory.GetCurrentDirectory() + "\\Lettres\\1.PNG"; // @"D:\Lettres\1.PNG";
            Chemin_img[1] = Directory.GetCurrentDirectory() + "\\Lettres\\2.PNG";
            Chemin_img[2] = Directory.GetCurrentDirectory() + "\\Lettres\\3.PNG";
            Chemin_img[3] = Directory.GetCurrentDirectory() + "\\Lettres\\4.PNG";
            Chemin_img[4] = Directory.GetCurrentDirectory() + "\\Lettres\\5.PNG";
            Chemin_img[5] = Directory.GetCurrentDirectory() + "\\Lettres\\6.PNG";
            Chemin_img[6] = Directory.GetCurrentDirectory() + "\\Lettres\\7.PNG";
            Chemin_img[7] = Directory.GetCurrentDirectory() + "\\Lettres\\8.PNG";
            Chemin_img[8] = Directory.GetCurrentDirectory() + "\\Lettres\\9.PNG";
            Chemin_img[9] = Directory.GetCurrentDirectory() + "\\Lettres\\10.PNG";
            Chemin_img[10] = Directory.GetCurrentDirectory() + "\\Lettres\\11.PNG";
            Chemin_img[11] = Directory.GetCurrentDirectory() + "\\Lettres\\12.PNG";
            Chemin_img[12] = Directory.GetCurrentDirectory() + "\\Lettres\\13.PNG";
            Chemin_img[13] = Directory.GetCurrentDirectory() + "\\Lettres\\14.PNG";
            Chemin_img[14] = Directory.GetCurrentDirectory() + "\\Lettres\\15.PNG";
            Chemin_img[15] = Directory.GetCurrentDirectory() + "\\Lettres\\16.PNG";
            Chemin_img[16] = Directory.GetCurrentDirectory() + "\\Lettres\\17.PNG";
            Chemin_img[17] = Directory.GetCurrentDirectory() + "\\Lettres\\18.PNG";
            Chemin_img[18] = Directory.GetCurrentDirectory() + "\\Lettres\\19.PNG";
            Chemin_img[19] = Directory.GetCurrentDirectory() + "\\Lettres\\20.PNG";
        }

        void Afficher_Image(Image img, string pathh)
        {
            BitmapImage bmp = new BitmapImage(new Uri(pathh, UriKind.Relative));
            //bmp.UriSource = new Uri(Directory.GetCurrentDirectory()+"\\Logo\\MT.PNG",UriKind.Relative);
            img.Width = bmp.Width;
            img.Height = bmp.Height;
            img.Stretch = Stretch.None;
            img.Source = bmp;

        }
        int pos = 0;
        Boolean boly = false;

        private void button_Click(object sender, RoutedEventArgs e)
        {
            image1.Visibility = Visibility.Collapsed;
            image2.Visibility = Visibility.Collapsed;
            textBlock1.Visibility = Visibility.Collapsed;
            Afficher_Image(image, Chemin_img[pos]);
            Tr.Start();
            pos++;
        }

        int timeleft = 110;
        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            int y = 0;
            if (pos < 20)
            {
                if (timeleft > 0)
                {
                    timeleft--;
                }
                else
                {
                    Tr.Stop();
                    Afficher_Image(image, Chemin_img[pos]);
                    pos++;
                    timeleft = 110;
                    Tr.Start();
                }
            }
            else
            {
                Tr.Stop();
                Test_Result tr = new Test_Result();
                tr.Show();
                Close();
            }
        }
    }
}
