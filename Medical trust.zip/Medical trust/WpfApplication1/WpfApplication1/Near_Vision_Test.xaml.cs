﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for Near_Vision_Test.xaml
    /// </summary>
    public partial class Near_Vision_Test : Window
    {
        public Near_Vision_Test()
        {
            InitializeComponent();
            TB1.Text = "Position yourself about 33 cm from the screen. Hide one eye, then the other, as if to test distance vision, so to control each eye separately.You should be able to read this distance the text in full.";
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            ChooseTest ct = new ChooseTest();
            ct.Show();
            this.Close();
        }
    }
}
