﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

using Windows.Graphics.Imaging;
using Windows.Storage;
using Windows.UI.Popups;
using Windows.Storage.Pickers;
using Windows.Storage.Streams;
using Windows.UI.Xaml.Media.Imaging;

// Pour en savoir plus sur le modèle d'élément Page vierge, consultez la page http://go.microsoft.com/fwlink/?LinkId=234238

namespace Your_Photo_is_a_puzzle
{
    /// <summary>
    /// Une page vide peut être utilisée seule ou constituer une page de destination au sein d'un frame.
    /// </summary>
    public sealed partial class Hard : Page
    {
        Random rand;
        List<int> L;
        BitmapDecoder decoder;
        public BitmapImage bmp;//= new BitmapImage();
        BitmapImage bpim1;
        InMemoryRandomAccessStream ras;
        BitmapEncoder enc;
        BitmapBounds bounds;
        uint N = 500;
        uint M = 62;

        Boolean VerifExist(List<int> LL, int r)
        {
            for (int i = 0; i < LL.Count; i++)
            {
                if (LL[i] == r) return true;//l'element exist
            }
            return false;
        }

        async void IsWin()
        {
            if  (
                (
                ((String)img1.Tag == "1") &&
                ((String)img2.Tag == "2") &&
                ((String)img3.Tag == "3") &&
                ((String)img4.Tag == "4") &&
                ((String)img5.Tag == "5") &&
                ((String)img6.Tag == "6") &&
                ((String)img7.Tag == "7") &&
                ((String)img8.Tag == "8") &&
                ((String)img9.Tag == "9") &&
                ((String)img10.Tag == "10") &&
                ((String)img11.Tag == "11") &&
                ((String)img12.Tag == "12") &&
                ((String)img13.Tag == "13") &&
                ((String)img14.Tag == "14") &&
                ((String)img15.Tag == "15") &&
                ((String)img16.Tag == "16") &&
                ((String)img17.Tag == "17") &&
                ((String)img18.Tag == "18") &&
                ((String)img19.Tag == "19") &&
                ((String)img20.Tag == "20") &&
                ((String)img21.Tag == "21") &&
                ((String)img22.Tag == "22") &&
                ((String)img23.Tag == "23") &&
                ((String)img24.Tag == "24") &&
                ((String)img25.Tag == "25") &&
                ((String)img26.Tag == "26") &&
                ((String)img27.Tag == "27") &&
                ((String)img28.Tag == "28") &&
                ((String)img29.Tag == "29") &&
                ((String)img30.Tag == "30") &&
                ((String)img31.Tag == "31") &&
                ((String)img32.Tag == "32") &&
                ((String)img33.Tag == "33") &&
                ((String)img34.Tag == "34") &&
                ((String)img35.Tag == "35") &&
                ((String)img36.Tag == "36") &&
                ((String)img37.Tag == "37") &&
                ((String)img38.Tag == "38") &&
                ((String)img39.Tag == "39") &&
                ((String)img40.Tag == "40") &&
                ((String)img41.Tag == "41") &&
                ((String)img42.Tag == "42") &&
                ((String)img43.Tag == "43") &&
                ((String)img44.Tag == "44") &&
                ((String)img45.Tag == "45") &&
                ((String)img46.Tag == "46") &&
                ((String)img47.Tag == "47") &&
                ((String)img48.Tag == "48") &&
                ((String)img49.Tag == "49") &&
                ((String)img50.Tag == "50") &&
                ((String)img51.Tag == "51") &&
                ((String)img52.Tag == "52") &&
                ((String)img53.Tag == "53") &&
                ((String)img54.Tag == "54") &&
                ((String)img55.Tag == "55") &&
                ((String)img56.Tag == "56") &&
                ((String)img57.Tag == "57") &&
                ((String)img58.Tag == "58") &&
                ((String)img59.Tag == "59") &&
                ((String)img60.Tag == "60") &&
                ((String)img61.Tag == "61") &&
                ((String)img62.Tag == "62") &&
                ((String)img63.Tag == "63") 
                ) 
                )
            {
                // Create a MessageDialog
                var messageDialog = new MessageDialog("You won, Congratulations.");
                messageDialog.Title = "Winning";
                // Or create a separate callback for different commands
                messageDialog.Commands.Add(new UICommand(
                    "OK", new UICommandInvokedHandler(this.CommandInvokedHandler1)));
                // Set CommandIndex. 0 means default.
                messageDialog.DefaultCommandIndex = 0;
                // Show MessageDialog
                await messageDialog.ShowAsync();
            }
        }

        private void CommandInvokedHandler1(IUICommand command)
        {
            // Do something here on the command handler
        }

        private void Img1_Click(object sender, RoutedEventArgs e)
        {
            if (img1.Source != null)
            {
                if (img2.Source == null)
                {
                    img2.Source = img1.Source;
                    img2.Tag = img1.Tag;
                    img1.Source = null;
                    IsWin();
                }
                if (img9.Source == null)
                {
                    img9.Source = img1.Source;
                    img9.Tag = img1.Tag;
                    img1.Source = null;
                    IsWin();
                }
            }
        }

        private void Img2_Click(object sender, RoutedEventArgs e)
        {
            if (img2.Source != null)
            {
                if (img1.Source == null)
                {
                    img1.Source = img2.Source;
                    img1.Tag = img2.Tag;
                    img2.Source = null;
                    IsWin();
                }
                if (img10.Source == null)
                {
                    img10.Source = img2.Source;
                    img10.Tag = img2.Tag;
                    img2.Source = null;
                    IsWin();
                }
                if (img3.Source == null)
                {
                    img3.Source = img2.Source;
                    img3.Tag = img2.Tag;
                    img2.Source = null;
                    IsWin();
                }
            }
        }
        private void Img3_Click(object sender, RoutedEventArgs e)
        {
            if (img3.Source != null)
            {
                if (img2.Source == null)
                {
                    img2.Source = img3.Source;
                    img2.Tag = img3.Tag;
                    img3.Source = null;
                    IsWin();
                }
                if (img11.Source == null)
                {
                    img11.Source = img3.Source;
                    img11.Tag = img3.Tag;
                    img3.Source = null;
                    IsWin();
                }
                if (img4.Source == null)
                {
                    img4.Source = img3.Source;
                    img4.Tag = img3.Tag;
                    img3.Source = null;
                    IsWin();
                }
            }
        }

        private void Img4_Click(object sender, RoutedEventArgs e)
        {
            if (img4.Source != null)
            {
                if (img3.Source == null)
                {
                    img3.Source = img4.Source;
                    img3.Tag = img4.Tag;
                    img4.Source = null;
                    IsWin();
                }
                if (img12.Source == null)
                {
                    img12.Source = img4.Source;
                    img12.Tag = img4.Tag;
                    img4.Source = null;
                    IsWin();
                }
                if (img5.Source == null)
                {
                    img5.Source = img4.Source;
                    img5.Tag = img4.Tag;
                    img4.Source = null;
                    IsWin();
                }
            }
        }

        private void Img5_Click(object sender, RoutedEventArgs e)
        {
            if (img5.Source != null)
            {
                if (img4.Source == null)
                {
                    img4.Source = img5.Source;
                    img4.Tag = img5.Tag;
                    img5.Source = null;
                    IsWin();
                }
                if (img6.Source == null)
                {
                    img6.Source = img5.Source;
                    img6.Tag = img5.Tag;
                    img5.Source = null;
                    IsWin();
                }
                if (img13.Source == null)
                {
                    img13.Source = img5.Source;
                    img13.Tag = img5.Tag;
                    img5.Source = null;
                    IsWin();
                }
            }
        }

        private void Img6_Click(object sender, RoutedEventArgs e)
        {
            if (img6.Source != null)
            {
                if (img5.Source == null)
                {
                    img5.Source = img6.Source;
                    img5.Tag = img6.Tag;
                    img6.Source = null;
                    IsWin();
                }
                if (img7.Source == null)
                {
                    img7.Source = img4.Source;
                    img7.Tag = img4.Tag;
                    img6.Source = null;
                    IsWin();
                }
                if (img14.Source == null)
                {
                    img14.Source = img6.Source;
                    img14.Tag = img6.Tag;
                    img6.Source = null;
                    IsWin();
                }
            }
        }

        private void Img7_Click(object sender, RoutedEventArgs e)
        {
            if (img7.Source != null)
            {
                if (img6.Source == null)
                {
                    img6.Source = img7.Source;
                    img6.Tag = img7.Tag;
                    img7.Source = null;
                    IsWin();
                }
                if (img8.Source == null)
                {
                    img8.Source = img7.Source;
                    img8.Tag = img7.Tag;
                    img7.Source = null;
                    IsWin();
                }
                if (img15.Source == null)
                {
                    img15.Source = img7.Source;
                    img15.Tag = img7.Tag;
                    img7.Source = null;
                    IsWin();
                }
            }
        }

        private void Img8_Click(object sender, RoutedEventArgs e)
        {
            if (img8.Source != null)
            {
                if (img7.Source == null)
                {
                    img7.Source = img8.Source;
                    img7.Tag = img8.Tag;
                    img8.Source = null;
                    IsWin();
                }
                if (img16.Source == null)
                {
                    img16.Source = img8.Source;
                    img16.Tag = img8.Tag;
                    img8.Source = null;
                    IsWin();
                }
            }
        }

        private void Img9_Click(object sender, RoutedEventArgs e)
        {
            if (img9.Source != null)
            {
                if (img1.Source == null)
                {
                    img1.Source = img9.Source;
                    img1.Tag = img9.Tag;
                    img9.Source = null;
                    IsWin();
                }
                if (img10.Source == null)
                {
                    img10.Source = img9.Source;
                    img10.Tag = img9.Tag;
                    img9.Source = null;
                    IsWin();
                }
                if (img17.Source == null)
                {
                    img17.Source = img9.Source;
                    img17.Tag = img9.Tag;
                    img9.Source = null;
                    IsWin();
                }
            }
        }

        private void Img10_Click(object sender, RoutedEventArgs e)
        {
            if (img10.Source != null)
            {
                if (img2.Source == null)
                {
                    img2.Source = img10.Source;
                    img2.Tag = img10.Tag;
                    img10.Source = null;
                    IsWin();
                }
                if (img9.Source == null)
                {
                    img9.Source = img10.Source;
                    img9.Tag = img10.Tag;
                    img10.Source = null;
                    IsWin();
                }
                if (img18.Source == null)
                {
                    img18.Source = img10.Source;
                    img18.Tag = img10.Tag;
                    img10.Source = null;
                    IsWin();
                }
                if (img11.Source == null)
                {
                    img11.Source = img10.Source;
                    img11.Tag = img10.Tag;
                    img10.Source = null;
                    IsWin();
                }
            }
        }

        private void Img11_Click(object sender, RoutedEventArgs e)
        {
            if (img11.Source != null)
            {
                if (img3.Source == null)
                {
                    img3.Source = img11.Source;
                    img3.Tag = img11.Tag;
                    img11.Source = null;
                    IsWin();
                }
                if (img10.Source == null)
                {
                    img10.Source = img11.Source;
                    img10.Tag = img11.Tag;
                    img11.Source = null;
                    IsWin();
                }
                if (img19.Source == null)
                {
                    img19.Source = img11.Source;
                    img19.Tag = img11.Tag;
                    img11.Source = null;
                    IsWin();
                }
                if (img12.Source == null)
                {
                    img12.Source = img11.Source;
                    img12.Tag = img11.Tag;
                    img11.Source = null;
                    IsWin();
                }
            }
        }

        private void Img12_Click(object sender, RoutedEventArgs e)
        {
            if (img12.Source != null)
            {
                if (img4.Source == null)
                {
                    img4.Source = img12.Source;
                    img4.Tag = img12.Tag;
                    img12.Source = null;
                    IsWin();
                }
                if (img11.Source == null)
                {
                    img11.Source = img12.Source;
                    img11.Tag = img12.Tag;
                    img12.Source = null;
                    IsWin();
                }
                if (img13.Source == null)
                {
                    img13.Source = img12.Source;
                    img13.Tag = img12.Tag;
                    img12.Source = null;
                    IsWin();
                }
                if (img20.Source == null)
                {
                    img20.Source = img12.Source;
                    img20.Tag = img12.Tag;
                    img12.Source = null;
                    IsWin();
                }
            }
        }

        private void Img13_Click(object sender, RoutedEventArgs e)
        {
            if (img13.Source != null)
            {
                if (img5.Source == null)
                {
                    img5.Source = img13.Source;
                    img5.Tag = img13.Tag;
                    img13.Source = null;
                    IsWin();
                }
                if (img12.Source == null)
                {
                    img12.Source = img13.Source;
                    img12.Tag = img13.Tag;
                    img13.Source = null;
                    IsWin();
                }
                if (img21.Source == null)
                {
                    img21.Source = img13.Source;
                    img21.Tag = img13.Tag;
                    img13.Source = null;
                    IsWin();
                }
                if (img14.Source == null)
                {
                    img14.Source = img13.Source;
                    img14.Tag = img13.Tag;
                    img13.Source = null;
                    IsWin();
                }
            }
        }

        private void Img14_Click(object sender, RoutedEventArgs e)
        {
            if (img14.Source != null)
            {
                if (img13.Source == null)
                {
                    img13.Source = img14.Source;
                    img13.Tag = img14.Tag;
                    img14.Source = null;
                    IsWin();
                }
                if (img13.Source == null)
                {
                    img13.Source = img14.Source;
                    img13.Tag = img14.Tag;
                    img14.Source = null;
                    IsWin();
                }
                if (img22.Source == null)
                {
                    img22.Source = img14.Source;
                    img22.Tag = img14.Tag;
                    img14.Source = null;
                    IsWin();
                }
                if (img15.Source == null)
                {
                    img15.Source = img14.Source;
                    img15.Tag = img14.Tag;
                    img14.Source = null;
                    IsWin();
                }
            }
        }
        private void Img15_Click(object sender, RoutedEventArgs e)
        {
            if (img15.Source != null)
            {
                if (img14.Source == null)
                {
                    img14.Source = img15.Source;
                    img14.Tag = img15.Tag;
                    img14.Source = null;
                    IsWin();
                }
                if (img23.Source == null)
                {
                    img23.Source = img15.Source;
                    img23.Tag = img15.Tag;
                    img15.Source = null;
                    IsWin();
                }
                if (img7.Source == null)
                {
                    img7.Source = img15.Source;
                    img7.Tag = img15.Tag;
                    img15.Source = null;
                    IsWin();
                }
                if (img16.Source == null)
                {
                    img16.Source = img15.Source;
                    img16.Tag = img15.Tag;
                    img15.Source = null;
                    IsWin();
                }
            }
        }

        private void Img16_Click(object sender, RoutedEventArgs e)
        {
            if (img16.Source != null)
            {
                if (img15.Source == null)
                {
                    img15.Source = img16.Source;
                    img15.Tag = img16.Tag;
                    img16.Source = null;
                    IsWin();
                }
                if (img24.Source == null)
                {
                    img24.Source = img16.Source;
                    img24.Tag = img16.Tag;
                    img16.Source = null;
                    IsWin();
                }
                if (img8.Source == null)
                {
                    img8.Source = img16.Source;
                    img8.Tag = img16.Tag;
                    img16.Source = null;
                    IsWin();
                }
            }
        }
/************************************************************************************************************************************/
        private void Img17_Click(object sender, RoutedEventArgs e)
        {
            if (img17.Source != null)
            {
                if (img18.Source == null)
                {
                    img18.Source = img17.Source;
                    img18.Tag = img17.Tag;
                    img17.Source = null;
                    IsWin();
                }
                if (img9.Source == null)
                {
                    img9.Source = img17.Source;
                    img9.Tag = img17.Tag;
                    img17.Source = null;
                    IsWin();
                }
                if (img25.Source == null)
                {
                    img25.Source = img17.Source;
                    img25.Tag = img17.Tag;
                    img17.Source = null;
                    IsWin();
                }
            }
        }

        private void Img18_Click(object sender, RoutedEventArgs e)
        {
            if (img18.Source != null)
            {
                if (img17.Source == null)
                {
                    img17.Source = img18.Source;
                    img17.Tag = img18.Tag;
                    img18.Source = null;
                    IsWin();
                }
                if (img10.Source == null)
                {
                    img10.Source = img18.Source;
                    img10.Tag = img18.Tag;
                    img18.Source = null;
                    IsWin();
                }
                if (img19.Source == null)
                {
                    img19.Source = img18.Source;
                    img19.Tag = img18.Tag;
                    img18.Source = null;
                    IsWin();
                }
                if (img26.Source == null)
                {
                    img26.Source = img18.Source;
                    img26.Tag = img18.Tag;
                    img18.Source = null;
                    IsWin();
                }
            }
        }
        private void Img19_Click(object sender, RoutedEventArgs e)
        {
            if (img19.Source != null)
            {
                if (img20.Source == null)
                {
                    img20.Source = img19.Source;
                    img20.Tag = img19.Tag;
                    img19.Source = null;
                    IsWin();
                }
                if (img11.Source == null)
                {
                    img11.Source = img19.Source;
                    img11.Tag = img19.Tag;
                    img19.Source = null;
                    IsWin();
                }
                if (img18.Source == null)
                {
                    img18.Source = img19.Source;
                    img18.Tag = img19.Tag;
                    img19.Source = null;
                    IsWin();
                }
                if (img29.Source == null)
                {
                    img29.Source = img19.Source;
                    img29.Tag = img19.Tag;
                    img19.Source = null;
                    IsWin();
                }
            }
        }

        private void Img20_Click(object sender, RoutedEventArgs e)
        {
            if (img20.Source != null)
            {
                if (img19.Source == null)
                {
                    img19.Source = img20.Source;
                    img19.Tag = img20.Tag;
                    img20.Source = null;
                    IsWin();
                }
                if (img12.Source == null)
                {
                    img12.Source = img20.Source;
                    img12.Tag = img20.Tag;
                    img20.Source = null;
                    IsWin();
                }
                if (img28.Source == null)
                {
                    img28.Source = img20.Source;
                    img28.Tag = img20.Tag;
                    img20.Source = null;
                    IsWin();
                }
                if (img21.Source == null)
                {
                    img21.Source = img20.Source;
                    img21.Tag = img20.Tag;
                    img20.Source = null;
                    IsWin();
                }
            }
        }

        private void Img21_Click(object sender, RoutedEventArgs e)
        {
            if (img21.Source != null)
            {
                
                if (img13.Source == null)
                {
                    img13.Source = img21.Source;
                    img13.Tag = img21.Tag;
                    img21.Source = null;
                    IsWin();
                }
                if (img20.Source == null)
                {
                    img20.Source = img21.Source;
                    img20.Tag = img21.Tag;
                    img21.Source = null;
                    IsWin();
                }
                if (img29.Source == null)
                {
                    img29.Source = img21.Source;
                    img29.Tag = img21.Tag;
                    img21.Source = null;
                    IsWin();
                }
                if (img22.Source == null)
                {
                    img22.Source = img21.Source;
                    img22.Tag = img21.Tag;
                    img21.Source = null;
                    IsWin();
                }
            }
        }

        private void Img22_Click(object sender, RoutedEventArgs e)
        {
            if (img22.Source != null)
            {
                
                if (img14.Source == null)
                {
                    img14.Source = img22.Source;
                    img14.Tag = img22.Tag;
                    img22.Source = null;
                    IsWin();
                }
                if (img21.Source == null)
                {
                    img21.Source = img22.Source;
                    img21.Tag = img22.Tag;
                    img22.Source = null;
                    IsWin();
                }
                if (img30.Source == null)
                {
                    img30.Source = img22.Source;
                    img30.Tag = img22.Tag;
                    img22.Source = null;
                    IsWin();
                }
                if (img23.Source == null)
                {
                    img23.Source = img22.Source;
                    img23.Tag = img22.Tag;
                    img22.Source = null;
                    IsWin();
                }
            }
        }

        private void Img23_Click(object sender, RoutedEventArgs e)
        {
            if (img23.Source != null)
            {
                
                if (img15.Source == null)
                {
                    img15.Source = img23.Source;
                    img15.Tag = img23.Tag;
                    img23.Source = null;
                    IsWin();
                }
                if (img22.Source == null)
                {
                    img22.Source = img23.Source;
                    img22.Tag = img23.Tag;
                    img23.Source = null;
                    IsWin();
                }
                if (img31.Source == null)
                {
                    img31.Source = img23.Source;
                    img31.Tag = img23.Tag;
                    img23.Source = null;
                    IsWin();
                }
                if (img24.Source == null)
                {
                    img24.Source = img23.Source;
                    img24.Tag = img23.Tag;
                    img23.Source = null;
                    IsWin();
                }
            }
        }

        private void Img24_Click(object sender, RoutedEventArgs e)
        {
            if (img24.Source != null)
            {
                if (img16.Source == null)
                {
                    img16.Source = img24.Source;
                    img16.Tag = img24.Tag;
                    img24.Source = null;
                    IsWin();
                }
                if (img23.Source == null)
                {
                    img23.Source = img24.Source;
                    img23.Tag = img24.Tag;
                    img24.Source = null;
                    IsWin();
                }
                if (img32.Source == null)
                {
                    img32.Source = img24.Source;
                    img32.Tag = img24.Tag;
                    img24.Source = null;
                    IsWin();
                }
            }
        }

        private void Img25_Click(object sender, RoutedEventArgs e)
        {
            if (img25.Source != null)
            {
                if (img17.Source == null)
                {
                    img17.Source = img25.Source;
                    img17.Tag = img25.Tag;
                    img25.Source = null;
                    IsWin();
                }
                if (img26.Source == null)
                {
                    img26.Source = img25.Source;
                    img26.Tag = img25.Tag;
                    img25.Source = null;
                    IsWin();
                }
                if (img33.Source == null)
                {
                    img33.Source = img25.Source;
                    img33.Tag = img25.Tag;
                    img25.Source = null;
                    IsWin();
                }
            }
        }

        private void Img26_Click(object sender, RoutedEventArgs e)
        {
            if (img26.Source != null)
            {
                
                if (img18.Source == null)
                {
                    img18.Source = img26.Source;
                    img18.Tag = img26.Tag;
                    img26.Source = null;
                    IsWin();
                }
                if (img25.Source == null)
                {
                    img25.Source = img26.Source;
                    img25.Tag = img26.Tag;
                    img26.Source = null;
                    IsWin();
                }
                if (img34.Source == null)
                {
                    img34.Source = img26.Source;
                    img34.Tag = img26.Tag;
                    img26.Source = null;
                    IsWin();
                }
                if (img27.Source == null)
                {
                    img27.Source = img26.Source;
                    img27.Tag = img26.Tag;
                    img26.Source = null;
                    IsWin();
                }
            }
        }

        private void Img27_Click(object sender, RoutedEventArgs e)
        {
            if (img27.Source != null)
            {
                if (img19.Source == null)
                {
                    img19.Source = img27.Source;
                    img19.Tag = img27.Tag;
                    img27.Source = null;
                    IsWin();
                }
                if (img26.Source == null)
                {
                    img26.Source = img27.Source;
                    img26.Tag = img27.Tag;
                    img27.Source = null;
                    IsWin();
                }
                if (img28.Source == null)
                {
                    img28.Source = img27.Source;
                    img28.Tag = img27.Tag;
                    img27.Source = null;
                    IsWin();
                }
                if (img35.Source == null)
                {
                    img35.Source = img27.Source;
                    img35.Tag = img27.Tag;
                    img27.Source = null;
                    IsWin();
                }
            }
        }

        private void Img28_Click(object sender, RoutedEventArgs e)
        {
            if (img28.Source != null)
            {
                if (img20.Source == null)
                {
                    img20.Source = img28.Source;
                    img20.Tag = img28.Tag;
                    img28.Source = null;
                    IsWin();
                }
                if (img27.Source == null)
                {
                    img27.Source = img28.Source;
                    img27.Tag = img28.Tag;
                    img28.Source = null;
                    IsWin();
                }
                if (img36.Source == null)
                {
                    img36.Source = img28.Source;
                    img36.Tag = img28.Tag;
                    img28.Source = null;
                    IsWin();
                }
                if (img29.Source == null)
                {
                    img29.Source = img28.Source;
                    img29.Tag = img28.Tag;
                    img28.Source = null;
                    IsWin();
                }
            }
        }

        private void Img29_Click(object sender, RoutedEventArgs e)
        {
            if (img13.Source != null)
            {
                if (img21.Source == null)
                {
                    img21.Source = img29.Source;
                    img21.Tag = img29.Tag;
                    img29.Source = null;
                    IsWin();
                }
                if (img28.Source == null)
                {
                    img28.Source = img29.Source;
                    img28.Tag = img29.Tag;
                    img29.Source = null;
                    IsWin();
                }
                if (img37.Source == null)
                {
                    img37.Source = img29.Source;
                    img37.Tag = img29.Tag;
                    img29.Source = null;
                    IsWin();
                }
                if (img30.Source == null)
                {
                    img30.Source = img29.Source;
                    img30.Tag = img29.Tag;
                    img29.Source = null;
                    IsWin();
                }
            }
        }

        private void Img30_Click(object sender, RoutedEventArgs e)
        {
            if (img30.Source != null)
            {
                if (img22.Source == null)
                {
                    img22.Source = img30.Source;
                    img22.Tag = img30.Tag;
                    img30.Source = null;
                    IsWin();
                }
                if (img29.Source == null)
                {
                    img29.Source = img30.Source;
                    img29.Tag = img30.Tag;
                    img30.Source = null;
                    IsWin();
                }
                if (img38.Source == null)
                {
                    img38.Source = img30.Source;
                    img38.Tag = img30.Tag;
                    img30.Source = null;
                    IsWin();
                }
                if (img31.Source == null)
                {
                    img31.Source = img30.Source;
                    img31.Tag = img30.Tag;
                    img30.Source = null;
                    IsWin();
                }
            }
        }
        private void Img31_Click(object sender, RoutedEventArgs e)
        {
            if (img31.Source != null)
            {
                if (img23.Source == null)
                {
                    img23.Source = img31.Source;
                    img23.Tag = img31.Tag;
                    img31.Source = null;
                    IsWin();
                }
                if (img30.Source == null)
                {
                    img30.Source = img31.Source;
                    img30.Tag = img31.Tag;
                    img31.Source = null;
                    IsWin();
                }
                if (img39.Source == null)
                {
                    img39.Source = img31.Source;
                    img39.Tag = img31.Tag;
                    img31.Source = null;
                    IsWin();
                }
                if (img32.Source == null)
                {
                    img32.Source = img31.Source;
                    img32.Tag = img31.Tag;
                    img31.Source = null;
                    IsWin();
                }
            }
        }

        private void Img32_Click(object sender, RoutedEventArgs e)
        {
            if (img32.Source != null)
            {
                if (img24.Source == null)
                {
                    img24.Source = img32.Source;
                    img24.Tag = img32.Tag;
                    img32.Source = null;
                    IsWin();
                }
                if (img31.Source == null)
                {
                    img31.Source = img32.Source;
                    img31.Tag = img32.Tag;
                    img32.Source = null;
                    IsWin();
                }
                if (img40.Source == null)
                {
                    img40.Source = img32.Source;
                    img40.Tag = img32.Tag;
                    img32.Source = null;
                    IsWin();
                }
            }
        }
/************************************************************************************************************************************/
/*************************************************************************************************************************************/
        private void Img33_Click(object sender, RoutedEventArgs e)
        {
            if (img33.Source != null)
            {
                if (img25.Source == null)
                {
                    img25.Source = img33.Source;
                    img25.Tag = img33.Tag;
                    img33.Source = null;
                    IsWin();
                }
                if (img34.Source == null)
                {
                    img34.Source = img33.Source;
                    img34.Tag = img33.Tag;
                    img33.Source = null;
                    IsWin();
                }
                if (img41.Source == null)
                {
                    img41.Source = img33.Source;
                    img41.Tag = img33.Tag;
                    img33.Source = null;
                    IsWin();
                }
            }
        }

        private void Img34_Click(object sender, RoutedEventArgs e)
        {
            if (img34.Source != null)
            {
                if (img33.Source == null)
                {
                    img33.Source = img34.Source;
                    img33.Tag = img34.Tag;
                    img34.Source = null;
                    IsWin();
                }
                if (img26.Source == null)
                {
                    img26.Source = img34.Source;
                    img26.Tag = img34.Tag;
                    img34.Source = null;
                    IsWin();
                }
                if (img35.Source == null)
                {
                    img35.Source = img34.Source;
                    img35.Tag = img34.Tag;
                    img34.Source = null;
                    IsWin();
                }
                if (img42.Source == null)
                {
                    img42.Source = img34.Source;
                    img42.Tag = img34.Tag;
                    img34.Source = null;
                    IsWin();
                }
            }
        }
        private void Img35_Click(object sender, RoutedEventArgs e)
        {
            if (img35.Source != null)
            {
                if (img36.Source == null)
                {
                    img36.Source = img35.Source;
                    img36.Tag = img35.Tag;
                    img35.Source = null;
                    IsWin();
                }
                if (img27.Source == null)
                {
                    img27.Source = img35.Source;
                    img27.Tag = img35.Tag;
                    img35.Source = null;
                    IsWin();
                }
                if (img34.Source == null)
                {
                    img34.Source = img35.Source;
                    img34.Tag = img35.Tag;
                    img35.Source = null;
                    IsWin();
                }
                if (img43.Source == null)
                {
                    img43.Source = img35.Source;
                    img43.Tag = img35.Tag;
                    img35.Source = null;
                    IsWin();
                }
            }
        }

        private void Img36_Click(object sender, RoutedEventArgs e)
        {
            if (img36.Source != null)
            {
                if (img37.Source == null)
                {
                    img37.Source = img36.Source;
                    img37.Tag = img36.Tag;
                    img36.Source = null;
                    IsWin();
                }
                if (img28.Source == null)
                {
                    img28.Source = img36.Source;
                    img28.Tag = img36.Tag;
                    img36.Source = null;
                    IsWin();
                }
                if (img35.Source == null)
                {
                    img35.Source = img36.Source;
                    img35.Tag = img36.Tag;
                    img36.Source = null;
                    IsWin();
                }
                if (img44.Source == null)
                {
                    img44.Source = img36.Source;
                    img44.Tag = img36.Tag;
                    img36.Source = null;
                    IsWin();
                }
            }
        }

        private void Img37_Click(object sender, RoutedEventArgs e)
        {
            if (img37.Source != null)
            {
                if (img38.Source == null)
                {
                    img38.Source = img37.Source;
                    img38.Tag = img37.Tag;
                    img37.Source = null;
                    IsWin();
                }
                if (img29.Source == null)
                {
                    img29.Source = img37.Source;
                    img29.Tag = img37.Tag;
                    img37.Source = null;
                    IsWin();
                }
                if (img36.Source == null)
                {
                    img36.Source = img37.Source;
                    img36.Tag = img37.Tag;
                    img37.Source = null;
                    IsWin();
                }
                if (img45.Source == null)
                {
                    img45.Source = img37.Source;
                    img45.Tag = img37.Tag;
                    img37.Source = null;
                    IsWin();
                }
            }
        }

        private void Img38_Click(object sender, RoutedEventArgs e)
        {
            if (img38.Source != null)
            {
                if (img39.Source == null)
                {
                    img39.Source = img38.Source;
                    img39.Tag = img38.Tag;
                    img38.Source = null;
                    IsWin();
                }
                if (img30.Source == null)
                {
                    img30.Source = img38.Source;
                    img30.Tag = img38.Tag;
                    img38.Source = null;
                    IsWin();
                }
                if (img37.Source == null)
                {
                    img37.Source = img38.Source;
                    img37.Tag = img38.Tag;
                    img38.Source = null;
                    IsWin();
                }
                if (img46.Source == null)
                {
                    img46.Source = img38.Source;
                    img46.Tag = img38.Tag;
                    img38.Source = null;
                    IsWin();
                }
            }
        }

        private void Img39_Click(object sender, RoutedEventArgs e)
        {
            if (img39.Source != null)
            {
                if (img40.Source == null)
                {
                    img40.Source = img39.Source;
                    img40.Tag = img39.Tag;
                    img39.Source = null;
                    IsWin();
                }
                if (img31.Source == null)
                {
                    img31.Source = img39.Source;
                    img31.Tag = img39.Tag;
                    img39.Source = null;
                    IsWin();
                }
                if (img38.Source == null)
                {
                    img38.Source = img39.Source;
                    img38.Tag = img39.Tag;
                    img39.Source = null;
                    IsWin();
                }
                if (img47.Source == null)
                {
                    img47.Source = img39.Source;
                    img47.Tag = img39.Tag;
                    img39.Source = null;
                    IsWin();
                }
            }
        }

        private void Img40_Click(object sender, RoutedEventArgs e)
        {
            if (img40.Source != null)
            {
                if (img32.Source == null)
                {
                    img32.Source = img40.Source;
                    img32.Tag = img40.Tag;
                    img40.Source = null;
                    IsWin();
                }
                if (img39.Source == null)
                {
                    img39.Source = img40.Source;
                    img39.Tag = img40.Tag;
                    img40.Source = null;
                    IsWin();
                }
                if (img48.Source == null)
                {
                    img48.Source = img40.Source;
                    img48.Tag = img40.Tag;
                    img40.Source = null;
                    IsWin();
                }
            }
        }

        private void Img41_Click(object sender, RoutedEventArgs e)
        {
            if (img41.Source != null)
            {
                if (img42.Source == null)
                {
                    img42.Source = img41.Source;
                    img42.Tag = img41.Tag;
                    img41.Source = null;
                    IsWin();
                }
                if (img33.Source == null)
                {
                    img33.Source = img41.Source;
                    img33.Tag = img41.Tag;
                    img41.Source = null;
                    IsWin();
                }
                if (img49.Source == null)
                {
                    img49.Source = img41.Source;
                    img49.Tag = img41.Tag;
                    img41.Source = null;
                    IsWin();
                }
            }
        }

        private void Img42_Click(object sender, RoutedEventArgs e)
        {
            if (img42.Source != null)
            {
                if (img43.Source == null)
                {
                    img43.Source = img42.Source;
                    img43.Tag = img42.Tag;
                    img42.Source = null;
                    IsWin();
                }
                if (img34.Source == null)
                {
                    img34.Source = img42.Source;
                    img34.Tag = img42.Tag;
                    img42.Source = null;
                    IsWin();
                }
                if (img41.Source == null)
                {
                    img41.Source = img42.Source;
                    img41.Tag = img42.Tag;
                    img42.Source = null;
                    IsWin();
                }
                if (img50.Source == null)
                {
                    img50.Source = img42.Source;
                    img50.Tag = img42.Tag;
                    img42.Source = null;
                    IsWin();
                }

            }
        }

        private void Img43_Click(object sender, RoutedEventArgs e)
        {
            if (img11.Source != null)
            {
                if (img44.Source == null)
                {
                    img44.Source = img43.Source;
                    img44.Tag = img43.Tag;
                    img43.Source = null;
                    IsWin();
                }
                if (img42.Source == null)
                {
                    img42.Source = img43.Source;
                    img42.Tag = img43.Tag;
                    img43.Source = null;
                    IsWin();
                }
                if (img35.Source == null)
                {
                    img35.Source = img43.Source;
                    img35.Tag = img43.Tag;
                    img43.Source = null;
                    IsWin();
                }
                if (img51.Source == null)
                {
                    img51.Source = img43.Source;
                    img51.Tag = img43.Tag;
                    img43.Source = null;
                    IsWin();
                }
            }
        }

        private void Img44_Click(object sender, RoutedEventArgs e)
        {
            if (img44.Source != null)
            {
                if (img45.Source == null)
                {
                    img45.Source = img44.Source;
                    img45.Tag = img44.Tag;
                    img44.Source = null;
                    IsWin();
                }
                if (img43.Source == null)
                {
                    img43.Source = img44.Source;
                    img43.Tag = img44.Tag;
                    img44.Source = null;
                    IsWin();
                }
                if (img36.Source == null)
                {
                    img36.Source = img44.Source;
                    img36.Tag = img44.Tag;
                    img44.Source = null;
                    IsWin();
                }
                if (img52.Source == null)
                {
                    img52.Source = img44.Source;
                    img52.Tag = img44.Tag;
                    img44.Source = null;
                    IsWin();
                }
            }
        }

        private void Img45_Click(object sender, RoutedEventArgs e)
        {
            if (img45.Source != null)
            {
                if (img46.Source == null)
                {
                    img46.Source = img45.Source;
                    img46.Tag = img45.Tag;
                    img45.Source = null;
                    IsWin();
                }
                if (img37.Source == null)
                {
                    img37.Source = img45.Source;
                    img37.Tag = img45.Tag;
                    img45.Source = null;
                    IsWin();
                }
                if (img44.Source == null)
                {
                    img44.Source = img45.Source;
                    img44.Tag = img45.Tag;
                    img45.Source = null;
                    IsWin();
                }
                if (img53.Source == null)
                {
                    img53.Source = img45.Source;
                    img53.Tag = img45.Tag;
                    img45.Source = null;
                    IsWin();
                }
            }
        }

        private void Img46_Click(object sender, RoutedEventArgs e)
        {
            if (img46.Source != null)
            {
                if (img38.Source == null)
                {
                    img38.Source = img46.Source;
                    img38.Tag = img46.Tag;
                    img46.Source = null;
                    IsWin();
                }
                if (img45.Source == null)
                {
                    img45.Source = img46.Source;
                    img45.Tag = img46.Tag;
                    img46.Source = null;
                    IsWin();
                }
                if (img54.Source == null)
                {
                    img54.Source = img46.Source;
                    img54.Tag = img46.Tag;
                    img46.Source = null;
                    IsWin();
                }
                if (img47.Source == null)
                {
                    img47.Source = img46.Source;
                    img47.Tag = img46.Tag;
                    img46.Source = null;
                    IsWin();
                }
            }
        }
        private void Img47_Click(object sender, RoutedEventArgs e)
        {
            if (img47.Source != null)
            {
                if (img39.Source == null)
                {
                    img39.Source = img47.Source;
                    img39.Tag = img47.Tag;
                    img47.Source = null;
                    IsWin();
                }
                if (img46.Source == null)
                {
                    img46.Source = img47.Source;
                    img46.Tag = img47.Tag;
                    img47.Source = null;
                    IsWin();
                }
                if (img48.Source == null)
                {
                    img48.Source = img47.Source;
                    img48.Tag = img47.Tag;
                    img47.Source = null;
                    IsWin();
                }
                if (img55.Source == null)
                {
                    img55.Source = img47.Source;
                    img55.Tag = img47.Tag;
                    img47.Source = null;
                    IsWin();
                }
            }
        }

        private void Img48_Click(object sender, RoutedEventArgs e)
        {
            if (img48.Source != null)
            {
                if (img40.Source == null)
                {
                    img40.Source = img48.Source;
                    img40.Tag = img48.Tag;
                    img48.Source = null;
                    IsWin();
                }
                if (img47.Source == null)
                {
                    img47.Source = img48.Source;
                    img47.Tag = img48.Tag;
                    img48.Source = null;
                    IsWin();
                }
                if (img56.Source == null)
                {
                    img56.Source = img48.Source;
                    img56.Tag = img48.Tag;
                    img48.Source = null;
                    IsWin();
                }
            }
        }
/************************************************************************************************************************************/
        private void Img49_Click(object sender, RoutedEventArgs e)
        {
            if (img49.Source != null)
            {
                if (img41.Source == null)
                {
                    img41.Source = img49.Source;
                    img41.Tag = img49.Tag;
                    img49.Source = null;
                    IsWin();
                }

                if (img50.Source == null)
                {
                    img50.Source = img49.Source;
                    img50.Tag = img49.Tag;
                    img49.Source = null;
                    IsWin();
                }
                if (img57.Source == null)
                {
                    img57.Source = img49.Source;
                    img57.Tag = img49.Tag;
                    img49.Source = null;
                    IsWin();
                }
            }
        }

        private void Img50_Click(object sender, RoutedEventArgs e)
        {
            if (img50.Source != null)
            {
               
                if (img42.Source == null)
                {
                    img42.Source = img50.Source;
                    img42.Tag = img50.Tag;
                    img50.Source = null;
                    IsWin();
                }
                if (img49.Source == null)
                {
                    img49.Source = img50.Source;
                    img49.Tag = img50.Tag;
                    img50.Source = null;
                    IsWin();
                }
                if (img51.Source == null)
                {
                    img51.Source = img50.Source;
                    img51.Tag = img50.Tag;
                    img50.Source = null;
                    IsWin();
                }
                if (img58.Source == null)
                {
                    img58.Source = img50.Source;
                    img58.Tag = img50.Tag;
                    img50.Source = null;
                    IsWin();
                }
            }
        }
        private void Img51_Click(object sender, RoutedEventArgs e)
        {
            if (img51.Source != null)
            {
                
                if (img43.Source == null)
                {
                    img43.Source = img51.Source;
                    img43.Tag = img51.Tag;
                    img51.Source = null;
                    IsWin();
                }
                if (img50.Source == null)
                {
                    img50.Source = img51.Source;
                    img50.Tag = img51.Tag;
                    img51.Source = null;
                    IsWin();
                }
                if (img59.Source == null)
                {
                    img59.Source = img51.Source;
                    img59.Tag = img51.Tag;
                    img51.Source = null;
                    IsWin();
                }
                if (img52.Source == null)
                {
                    img52.Source = img51.Source;
                    img52.Tag = img51.Tag;
                    img51.Source = null;
                    IsWin();
                }
            }
        }

        private void Img52_Click(object sender, RoutedEventArgs e)
        {
            if (img52.Source != null)
            {
                if (img53.Source == null)
                {
                    img53.Source = img52.Source;
                    img53.Tag = img52.Tag;
                    img52.Source = null;
                    IsWin();
                }
                if (img44.Source == null)
                {
                    img44.Source = img52.Source;
                    img44.Tag = img52.Tag;
                    img52.Source = null;
                    IsWin();
                }
                if (img51.Source == null)
                {
                    img51.Source = img52.Source;
                    img51.Tag = img52.Tag;
                    img52.Source = null;
                    IsWin();
                }
                if (img60.Source == null)
                {
                    img60.Source = img52.Source;
                    img60.Tag = img52.Tag;
                    img52.Source = null;
                    IsWin();
                }
            }
        }

        private void Img53_Click(object sender, RoutedEventArgs e)
        {
            if (img53.Source != null)
            {
                if (img54.Source == null)
                {
                    img54.Source = img53.Source;
                    img54.Tag = img53.Tag;
                    img53.Source = null;
                    IsWin();
                }
                if (img45.Source == null)
                {
                    img45.Source = img53.Source;
                    img45.Tag = img53.Tag;
                    img53.Source = null;
                    IsWin();
                }
                if (img52.Source == null)
                {
                    img52.Source = img53.Source;
                    img52.Tag = img53.Tag;
                    img53.Source = null;
                    IsWin();
                }
                if (img61.Source == null)
                {
                    img61.Source = img53.Source;
                    img61.Tag = img53.Tag;
                    img53.Source = null;
                    IsWin();
                }
            }
        }

        private void Img54_Click(object sender, RoutedEventArgs e)
        {
            if (img54.Source != null)
            {

                if (img53.Source == null)
                {
                    img53.Source = img54.Source;
                    img53.Tag = img54.Tag;
                    img54.Source = null;
                    IsWin();
                }
                if (img55.Source == null)
                {
                    img55.Source = img54.Source;
                    img55.Tag = img54.Tag;
                    img54.Source = null;
                    IsWin();
                }
                if (img46.Source == null)
                {
                    img46.Source = img54.Source;
                    img46.Tag = img54.Tag;
                    img54.Source = null;
                    IsWin();
                }
                if (img62.Source == null)
                {
                    img62.Source = img54.Source;
                    img62.Tag = img54.Tag;
                    img54.Source = null;
                    IsWin();
                }
            }
        }

        private void Img55_Click(object sender, RoutedEventArgs e)
        {
            if (img55.Source != null)
            {
                if (img56.Source == null)
                {
                    img56.Source = img55.Source;
                    img56.Tag = img55.Tag;
                    img55.Source = null;
                    IsWin();
                }
                if (img47.Source == null)
                {
                    img47.Source = img55.Source;
                    img47.Tag = img55.Tag;
                    img55.Source = null;
                    IsWin();
                }
                if (img54.Source == null)
                {
                    img54.Source = img55.Source;
                    img54.Tag = img55.Tag;
                    img55.Source = null;
                    IsWin();
                }
                if (img63.Source == null)
                {
                    img63.Source = img55.Source;
                    img63.Tag = img55.Tag;
                    img55.Source = null;
                    IsWin();
                }
            }
        }

        private void Img56_Click(object sender, RoutedEventArgs e)
        {
            if (img56.Source != null)
            {
                if (img48.Source == null)
                {
                    img48.Source = img56.Source;
                    img48.Tag = img56.Tag;
                    img56.Source = null;
                    IsWin();
                }
                if (img55.Source == null)
                {
                    img55.Source = img56.Source;
                    img55.Tag = img56.Tag;
                    img56.Source = null;
                    IsWin();
                }
                if (img64.Source == null)
                {
                    img64.Source = img56.Source;
                    img64.Tag = img56.Tag;
                    img56.Source = null;
                    IsWin();
                }
            }
        }

        private void Img57_Click(object sender, RoutedEventArgs e)
        {
            if (img57.Source != null)
            {
                if (img49.Source == null)
                {
                    img49.Source = img57.Source;
                    img49.Tag = img57.Tag;
                    img57.Source = null;
                    IsWin();
                }
                if (img58.Source == null)
                {
                    img58.Source = img57.Source;
                    img58.Tag = img57.Tag;
                    img57.Source = null;
                    IsWin();
                }
            }
        }

        private void Img58_Click(object sender, RoutedEventArgs e)
        {
            if (img58.Source != null)
            {
                if (img57.Source == null)
                {
                    img57.Source = img58.Source;
                    img57.Tag = img58.Tag;
                    img58.Source = null;
                    IsWin();
                }
                if (img50.Source == null)
                {
                    img50.Source = img58.Source;
                    img50.Tag = img58.Tag;
                    img58.Source = null;
                    IsWin();
                }
                if (img59.Source == null)
                {
                    img59.Source = img58.Source;
                    img59.Tag = img58.Tag;
                    img58.Source = null;
                    IsWin();
                }
            }
        }

        private void Img59_Click(object sender, RoutedEventArgs e)
        {
            if (img59.Source != null)
            {
                if (img51.Source == null)
                {
                    img51.Source = img59.Source;
                    img51.Tag = img59.Tag;
                    img59.Source = null;
                    IsWin();
                }
                if (img58.Source == null)
                {
                    img58.Source = img59.Source;
                    img58.Tag = img59.Tag;
                    img59.Source = null;
                    IsWin();
                }
                if (img60.Source == null)
                {
                    img60.Source = img59.Source;
                    img60.Tag = img59.Tag;
                    img59.Source = null;
                    IsWin();
                }
            }
        }

        private void Img60_Click(object sender, RoutedEventArgs e)
        {
            if (img60.Source != null)
            {
                if (img52.Source == null)
                {
                    img52.Source = img60.Source;
                    img52.Tag = img60.Tag;
                    img60.Source = null;
                    IsWin();
                }
                if (img59.Source == null)
                {
                    img59.Source = img60.Source;
                    img59.Tag = img60.Tag;
                    img60.Source = null;
                    IsWin();
                }
                if (img61.Source == null)
                {
                    img61.Source = img60.Source;
                    img61.Tag = img60.Tag;
                    img60.Source = null;
                    IsWin();
                }
            }
        }

        private void Img61_Click(object sender, RoutedEventArgs e)
        {
            if (img61.Source != null)
            {
                if (img53.Source == null)
                {
                    img53.Source = img61.Source;
                    img53.Tag = img61.Tag;
                    img61.Source = null;
                    IsWin();
                }
                if (img60.Source == null)
                {
                    img60.Source = img61.Source;
                    img60.Tag = img61.Tag;
                    img61.Source = null;
                    IsWin();
                }
                if (img62.Source == null)
                {
                    img62.Source = img61.Source;
                    img62.Tag = img61.Tag;
                    img61.Source = null;
                    IsWin();
                }
            }
        }

        private void Img62_Click(object sender, RoutedEventArgs e)
        {
            if (img62.Source != null)
            {
                if (img54.Source == null)
                {
                    img54.Source = img62.Source;
                    img54.Tag = img62.Tag;
                    img62.Source = null;
                    IsWin();
                }
                if (img61.Source == null)
                {
                    img61.Source = img62.Source;
                    img61.Tag = img62.Tag;
                    img62.Source = null;
                    IsWin();
                }
                if (img63.Source == null)
                {
                    img63.Source = img62.Source;
                    img63.Tag = img62.Tag;
                    img62.Source = null;
                    IsWin();
                }
            }
        }
        private void Img63_Click(object sender, RoutedEventArgs e)
        {
            if (img63.Source != null)
            {
                if (img55.Source == null)
                {
                    img55.Source = img63.Source;
                    img55.Tag = img63.Tag;
                    img63.Source = null;
                    IsWin();
                }
                if (img62.Source == null)
                {
                    img62.Source = img63.Source;
                    img62.Tag = img63.Tag;
                    img63.Source = null;
                    IsWin();
                }
                if (img64.Source == null)
                {
                    img64.Source = img63.Source;
                    img64.Tag = img63.Tag;
                    img63.Source = null;
                    IsWin();
                }
            }
        }

        private void Img64_Click(object sender, RoutedEventArgs e)
        {
            if (img64.Source != null)
            {
                if (img63.Source == null)
                {
                    img63.Source = img64.Source;
                    img63.Tag = img64.Tag;
                    img64.Source = null;
                    IsWin();
                }
                if (img56.Source == null)
                {
                    img56.Source = img64.Source;
                    img56.Tag = img64.Tag;
                    img64.Source = null;
                    IsWin();
                }
            }
        }
        /****************************************************************************************************************************/

        public Hard()
        {
            this.InitializeComponent();
            R3.IsChecked = true;


            img1.Tapped += Img1_Click;
            img2.Tapped += Img2_Click;
            img3.Tapped += Img3_Click;
            img4.Tapped += Img4_Click;
            img5.Tapped += Img5_Click;
            img6.Tapped += Img6_Click;
            img7.Tapped += Img7_Click;
            img8.Tapped += Img8_Click;
            img9.Tapped += Img9_Click;
            img10.Tapped += Img10_Click;
            img11.Tapped += Img11_Click;
            img12.Tapped += Img12_Click;
            img13.Tapped += Img13_Click;
            img14.Tapped += Img14_Click;
            img15.Tapped += Img15_Click;
            img16.Tapped += Img16_Click;
            img17.Tapped += Img17_Click;
            img18.Tapped += Img18_Click;
            img19.Tapped += Img19_Click;
            img20.Tapped += Img20_Click;
            img21.Tapped += Img21_Click;
            img22.Tapped += Img22_Click;
            img23.Tapped += Img23_Click;
            img24.Tapped += Img24_Click;
            img25.Tapped += Img25_Click;
            img26.Tapped += Img26_Click;
            img27.Tapped += Img27_Click;
            img28.Tapped += Img28_Click;
            img29.Tapped += Img29_Click;
            img30.Tapped += Img30_Click;
            img31.Tapped += Img31_Click;
            img32.Tapped += Img32_Click; 

            img33.Tapped += Img33_Click;
            img34.Tapped += Img34_Click;
            img35.Tapped += Img35_Click;
            img36.Tapped += Img36_Click;
            img37.Tapped += Img37_Click;
            img38.Tapped += Img38_Click;
            img39.Tapped += Img39_Click;
            img40.Tapped += Img40_Click;
            img41.Tapped += Img41_Click;
            img42.Tapped += Img42_Click;
            img43.Tapped += Img43_Click;
            img44.Tapped += Img44_Click;
            img45.Tapped += Img45_Click;
            img46.Tapped += Img46_Click;
            img47.Tapped += Img47_Click;
            img48.Tapped += Img48_Click;
            img49.Tapped += Img49_Click;
            img50.Tapped += Img50_Click;
            img51.Tapped += Img51_Click;
            img52.Tapped += Img52_Click;
            img53.Tapped += Img53_Click;
            img54.Tapped += Img54_Click;
            img55.Tapped += Img55_Click;
            img56.Tapped += Img56_Click;
            img57.Tapped += Img57_Click;
            img58.Tapped += Img58_Click;
            img59.Tapped += Img59_Click;
            img60.Tapped += Img60_Click;
            img61.Tapped += Img61_Click;
            img62.Tapped += Img62_Click;
            img63.Tapped += Img63_Click;
            img64.Tapped += Img64_Click;


            
        }


        Image ImgTemp = new Image();
       


        async private void Button_Click(object sender, RoutedEventArgs e)
        {
            //img1.Source = null;

            rand = new Random();
            L = new List<int>();
            //ouvrir un fileDialogue
            FileOpenPicker openPicker = new FileOpenPicker();
            openPicker.ViewMode = PickerViewMode.Thumbnail;
            openPicker.SuggestedStartLocation = PickerLocationId.PicturesLibrary;
            openPicker.FileTypeFilter.Add(".jpg");
            openPicker.FileTypeFilter.Add(".jpeg");
            openPicker.FileTypeFilter.Add(".bmp");
            openPicker.FileTypeFilter.Add(".png");
            StorageFile imgFile = await openPicker.PickSingleFileAsync();

            //////////////////////////////////////////////////////////////
            if (imgFile != null)
            {
                // Ensure the stream is disposed once the image is loaded
                using (IRandomAccessStream fileStream = await imgFile.OpenAsync(Windows.Storage.FileAccessMode.Read))
                {
                    bmp = new BitmapImage();
                    bmp.DecodePixelHeight = (int)N;
                    bmp.DecodePixelWidth = (int)N;

                    await bmp.SetSourceAsync(fileStream);
                    img0.Source = bmp;


                }

            
            /*********************************************************************************************************/
            var filestream = await imgFile.OpenAsync(Windows.Storage.FileAccessMode.Read);
            decoder = await BitmapDecoder.CreateAsync(filestream);

            uint X0 = 0;
            uint Y0 = 0;

            Boolean boly = true;
            int rem = 64;
            for (int i = 1; i <= 64; i++)
            {
                ras = null;
                enc = null;
                bpim1 = null;

                switch (i)
                {
                    case 1: X0 = 0;   Y0 = 0; break;
                    case 2: X0 = 62; Y0 = 0; break;
                    case 3: X0 = 125; Y0 = 0; break;
                    case 4: X0 = 188; Y0 = 0; break;
                    case 5: X0 = 250;   Y0 = 0; break;
                    case 6: X0 = 312; Y0 = 0; break;
                    case 7: X0 = 374; Y0 = 0; break;
                    case 8: X0 = 436; Y0 = 0; break;

                    case 9: X0 = 0; Y0 = 62; break;
                    case 10: X0 = 62; Y0 = 62; break;
                    case 11: X0 = 125; Y0 = 62; break;
                    case 12: X0 = 188; Y0 = 62; break;
                    case 13: X0 = 250; Y0 = 62; break;
                    case 14: X0 = 312; Y0 = 62; break;
                    case 15: X0 = 374; Y0 = 62; break;
                    case 16: X0 = 436; Y0 = 62; break;

                    case 17: X0 = 0; Y0 = 125; break;
                    case 18: X0 = 62; Y0 = 125; break;
                    case 19: X0 = 125; Y0 = 125; break;
                    case 20: X0 = 188; Y0 = 125; break;
                    case 21: X0 = 250; Y0 = 125; break;
                    case 22: X0 = 312; Y0 = 125; break;
                    case 23: X0 = 374; Y0 = 125; break;
                    case 24: X0 = 436; Y0 = 125; break;

                    case 25: X0 = 0; Y0 = 188; break;
                    case 26: X0 = 62; Y0 = 188; break;
                    case 27: X0 = 125; Y0 = 188; break;
                    case 28: X0 = 188; Y0 = 188; break;
                    case 29: X0 = 250; Y0 = 188; break;
                    case 30: X0 = 312; Y0 = 188; break;
                    case 31: X0 = 374; Y0 = 188; break;
                    case 32: X0 = 436; Y0 = 188; break;

                    case 33: X0 = 0; Y0 = 250; break;
                    case 34: X0 = 62; Y0 = 250; break;
                    case 35: X0 = 125; Y0 = 250; break;
                    case 36: X0 = 188; Y0 = 250; break;
                    case 37: X0 = 250; Y0 = 250; break;
                    case 38: X0 = 312; Y0 = 250; break;
                    case 39: X0 = 374; Y0 = 250; break;
                    case 40: X0 = 436; Y0 = 250; break;

                    case 41: X0 = 0; Y0 = 250; break;
                    case 42: X0 = 62; Y0 = 312; break;
                    case 43: X0 = 125; Y0 = 312; break;
                    case 44: X0 = 188; Y0 = 312; break;
                    case 45: X0 = 250; Y0 = 312; break;
                    case 46: X0 = 312; Y0 = 312; break;
                    case 47: X0 = 374; Y0 = 312; break;
                    case 48: X0 = 436; Y0 = 312; break;

                    case 49: X0 = 0; Y0 = 312; break;
                    case 50: X0 = 62; Y0 = 374; break;
                    case 51: X0 = 125; Y0 = 374; break;
                    case 52: X0 = 188; Y0 = 374; break;
                    case 53: X0 = 250; Y0 = 374; break;
                    case 54: X0 = 312; Y0 = 374; break;
                    case 55: X0 = 374; Y0 = 374; break;
                    case 56: X0 = 436; Y0 = 374; break;

                    case 57: X0 = 0; Y0 = 374; break;
                    case 58: X0 = 62; Y0 = 436; break;
                    case 59: X0 = 125; Y0 = 436; break;
                    case 60: X0 = 188; Y0 = 436; break;
                    case 61: X0 = 250; Y0 = 436; break;
                    case 62: X0 = 312; Y0 = 436; break;
                    case 63: X0 = 374; Y0 = 436; break;
                    case 64: X0 = 436; Y0 = 436; break;
                }

                ras = new InMemoryRandomAccessStream();
                enc = await BitmapEncoder.CreateForTranscodingAsync(ras, decoder);

                enc.BitmapTransform.ScaledWidth = N;
                enc.BitmapTransform.ScaledHeight = N;

                bounds = new BitmapBounds();
                bounds.Height = M;
                bounds.Width = M;
                bounds.X = X0;
                bounds.Y = Y0;

                enc.BitmapTransform.Bounds = bounds;

                try
                {
                    await enc.FlushAsync();
                }
                catch (Exception)
                {

                    throw;
                }

                bpim1 = new BitmapImage();
                bpim1.SetSource(ras);

                int r = rand.Next(2, 65);

                /* while ((VerifExist(L, r) == true) || (r == 65))
                {
                    r = rand.Next(2, 65);
                }*/

                if (i == 1)
                {
                    while (r == 65)
                    {
                        rand = new Random();
                        r = rand.Next(1, 65);
                    }
                    L.Add(r);
                }
                else
                {
                    while ((VerifExist(L, r) == true) || (r == 65))
                    {
                        rand = new Random();
                        r = rand.Next(1, 65);
                    }
                    L.Add(r);
                }

                switch (r)
                {
                    case 1: img1.Stretch = Stretch.None;
                        img1.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img1.Source = null;
                            }
                        }
                        img1.Tag = i.ToString();
                       // L.Add(1);
                        break;
                    case 2: img2.Stretch = Stretch.None;
                        img2.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img2.Source = null;
                            }
                        }
                        img2.Tag = i.ToString();
                       // L.Add(2);
                        break;
                    case 3: img3.Stretch = Stretch.None;
                        img3.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img3.Source = null;
                            }
                        }
                        img3.Tag = i.ToString();
                        //L.Add(3);
                        break;
                    case 4: img4.Stretch = Stretch.None;
                        img4.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img4.Source = null;
                            }
                        }
                        img4.Tag = i.ToString();
                       // L.Add(4);
                        break;
                    case 5: img5.Stretch = Stretch.None;
                        img5.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img5.Source = null;
                            }
                        }
                        img5.Tag = i.ToString();
                       // L.Add(5);
                        break;
                    case 6: img6.Stretch = Stretch.None;
                        img6.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img6.Source = null;
                            }
                        }
                        img6.Tag = i.ToString();
                       // L.Add(6);
                        break;
                    case 7: img7.Stretch = Stretch.None;
                        img7.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img7.Source = null;
                            }
                        }
                        img7.Tag = i.ToString();
                        //L.Add(7);
                        break;
                    case 8: img8.Stretch = Stretch.None;
                        img8.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img8.Source = null;
                            }
                        }
                        img8.Tag = i.ToString();
                        //L.Add(8);
                        break;
                    case 9: img9.Stretch = Stretch.None;
                        img9.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img9.Source = null;
                            }
                        }
                        img9.Tag = i.ToString();
                       // L.Add(9);
                        break;
                    case 10: img10.Stretch = Stretch.None;
                        img10.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img10.Source = null;
                            }
                        }
                        img10.Tag = i.ToString();
                        //L.Add(10);
                        break;
                    case 11: img11.Stretch = Stretch.None;
                        img11.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img11.Source = null;
                            }
                        }
                        img11.Tag = i.ToString();
                        //L.Add(11);
                        break;
                    case 12: img12.Stretch = Stretch.None;
                        img12.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img12.Source = null;
                            }
                        }
                        img12.Tag = i.ToString();
                        //L.Add(12);
                        break;
                    case 13: img13.Stretch = Stretch.None;
                        img13.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img13.Source = null;
                            }
                        }
                        img13.Tag = i.ToString();
                        //L.Add(13);
                        break;
                    case 14: img14.Stretch = Stretch.None;
                        img14.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img14.Source = null;
                            }
                        }
                        img14.Tag = i.ToString();
                        //L.Add(14);
                        break;
                    case 15: img15.Stretch = Stretch.None;
                        img15.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img15.Source = null;
                            }
                        }
                        img15.Tag = i.ToString();
                        //L.Add(15);
                        break;
                    case 16: img16.Stretch = Stretch.None;
                        img16.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img16.Source = null;
                            }
                        }
                        img16.Tag = i.ToString();
                        //L.Add(16);
                        break;
                    case 17: img17.Stretch = Stretch.None;
                        img17.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img17.Source = null;
                            }
                        }
                        img17.Tag = i.ToString();
                        //L.Add(17);
                        break;
                    case 18: img18.Stretch = Stretch.None;
                        img18.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img18.Source = null;
                            }
                        }
                        img18.Tag = i.ToString();
                        //L.Add(18);
                        break;
                    case 19: img19.Stretch = Stretch.None;
                        img19.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img19.Source = null;
                            }
                        }
                        img19.Tag = i.ToString();
                        //L.Add(19);
                        break;
                    case 20: img20.Stretch = Stretch.None;
                        img20.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img20.Source = null;
                            }
                        }
                        img20.Tag = i.ToString();
                        //L.Add(20);
                        break;
                    case 21: img21.Stretch = Stretch.None;
                        img21.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img21.Source = null;
                            }
                        }
                        img21.Tag = i.ToString();
                        //L.Add(21);
                        break;
                    case 22: img22.Stretch = Stretch.None;
                        img22.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img22.Source = null;
                            }
                        }
                        img22.Tag = i.ToString();
                        //L.Add(22);
                        break;
                    case 23: img23.Stretch = Stretch.None;
                        img23.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img23.Source = null;
                            }
                        }
                        img23.Tag = i.ToString();
                        //L.Add(23);
                        break;
                    case 24: img24.Stretch = Stretch.None;
                        img24.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img24.Source = null;
                            }
                        }
                        img24.Tag = i.ToString();
                       // L.Add(24);
                        break;
                    case 25: img25.Stretch = Stretch.None;
                        img25.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img25.Source = null;
                            }
                        }
                        img25.Tag = i.ToString();
                        //L.Add(25);
                        break;
                    case 26: img26.Stretch = Stretch.None;
                        img26.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img26.Source = null;
                            }
                        }
                        img26.Tag = i.ToString();
                        //L.Add(26);
                        break;
                    case 27: img27.Stretch = Stretch.None;
                        img27.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img27.Source = null;
                            }
                        }
                        img27.Tag = i.ToString();
                        //L.Add(27);
                        break;
                    case 28: img28.Stretch = Stretch.None;
                        img28.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img28.Source = null;
                            }
                        }
                        img28.Tag = i.ToString();
                        //L.Add(28);
                        break;
                    case 29: img29.Stretch = Stretch.None;
                        img29.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img29.Source = null;
                            }
                        }
                        img29.Tag = i.ToString();
                        //L.Add(29);
                        break;
                    case 30: img30.Stretch = Stretch.None;
                        img30.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img30.Source = null;
                            }
                        }
                        img30.Tag = i.ToString();
                        //L.Add(30);
                        break;
                    case 31: img31.Stretch = Stretch.None;
                        img31.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img31.Source = null;
                            }
                        }
                        img31.Tag = i.ToString();
                        //L.Add(31);
                        break;
                    case 32: img32.Stretch = Stretch.None;
                        img32.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img32.Source = null;
                            }
                        }
                        img32.Tag = i.ToString();
                       // L.Add(32);
                        break;
                    case 33: img33.Stretch = Stretch.None;
                        img33.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img33.Source = null;
                            }
                        }
                        img33.Tag = i.ToString();
                        //L.Add(33);
                        break;
                    case 34: img34.Stretch = Stretch.None;
                        img34.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img34.Source = null;
                            }
                        }
                        img34.Tag = i.ToString();
                        //L.Add(34);
                        break;
                    case 35: img35.Stretch = Stretch.None;
                        img35.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img35.Source = null;
                            }
                        }
                        img35.Tag = i.ToString();
                        //L.Add(35);
                        break;
                    case 36: img36.Stretch = Stretch.None;
                        img36.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img36.Source = null;
                            }
                        }
                        img36.Tag = i.ToString();
                        //L.Add(36);
                        break;
                    case 37: img37.Stretch = Stretch.None;
                        img37.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img37.Source = null;
                            }
                        }
                        img37.Tag = i.ToString();
                        //L.Add(37);
                        break;
                    case 38: img38.Stretch = Stretch.None;
                        img38.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img38.Source = null;
                            }
                        }
                        img38.Tag = i.ToString();
                        //L.Add(38);
                        break;
                    case 39: img39.Stretch = Stretch.None;
                        img39.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img39.Source = null;
                            }
                        }
                        img39.Tag = i.ToString();
                        //L.Add(39);
                        break;
                    case 40: img40.Stretch = Stretch.None;
                        img40.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img40.Source = null;
                            }
                        }
                        img40.Tag = i.ToString();
                        //L.Add(40);
                        break;
                    case 41: img41.Stretch = Stretch.None;
                        img41.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img41.Source = null;
                            }
                        }
                        img41.Tag = i.ToString();
                       // L.Add(41);
                        break;
                    case 42: img42.Stretch = Stretch.None;
                        img42.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img42.Source = null;
                            }
                        }
                        img42.Tag = i.ToString();
                        //L.Add(42);
                        break;
                    case 43: img43.Stretch = Stretch.None;
                        img43.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img43.Source = null;
                            }
                        }
                        img43.Tag = i.ToString();
                        //L.Add(43);
                        break;
                    case 44: img44.Stretch = Stretch.None;
                        img44.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img44.Source = null;
                            }
                        }
                        img44.Tag = i.ToString();
                        //L.Add(44);
                        break;
                    case 45: img45.Stretch = Stretch.None;
                        img45.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img45.Source = null;
                            }
                        }
                        img45.Tag = i.ToString();
                        //L.Add(45);
                        break;
                    case 46: img46.Stretch = Stretch.None;
                        img46.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img46.Source = null;
                            }
                        }
                        img46.Tag = i.ToString();
                        //L.Add(46);
                        break;
                    case 47: img47.Stretch = Stretch.None;
                        img47.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img47.Source = null;
                            }
                        }
                        img47.Tag = i.ToString();
                        //L.Add(47);
                        break;
                    case 48: img48.Stretch = Stretch.None;
                        img48.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img48.Source = null;
                            }
                        }
                        img48.Tag = i.ToString();
                        //L.Add(48);
                        break;
                    case 49: img49.Stretch = Stretch.None;
                        img49.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img49.Source = null;
                            }
                        }
                        img49.Tag = i.ToString();
                        //L.Add(49);
                        break;
                    case 50: img50.Stretch = Stretch.None;
                        img50.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img50.Source = null;
                            }
                        }
                        img50.Tag = i.ToString();
                        //L.Add(50);
                        break;
                    case 51: img51.Stretch = Stretch.None;
                        img51.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img51.Source = null;
                            }
                        }
                        img51.Tag = i.ToString();
                        //L.Add(51);
                        break;
                    case 52: img52.Stretch = Stretch.None;
                        img52.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img52.Source = null;
                            }
                        }
                        img52.Tag = i.ToString();
                        //L.Add(52);
                        break;
                    case 53: img53.Stretch = Stretch.None;
                        img53.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img53.Source = null;
                            }
                        }
                        img53.Tag = i.ToString();
                       // L.Add(53);
                        break;
                    case 54: img54.Stretch = Stretch.None;
                        img54.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img54.Source = null;
                            }
                        }
                        img54.Tag = i.ToString();
                       // L.Add(54);
                        break;
                    case 55: img55.Stretch = Stretch.None;
                        img55.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img55.Source = null;
                            }
                        }
                        img55.Tag = i.ToString();
                       // L.Add(55);
                        break;
                    case 56: img46.Stretch = Stretch.None;
                        img56.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img56.Source = null;
                            }
                        }
                        img56.Tag = i.ToString();
                       // L.Add(56);
                        break;
                    case 57: img57.Stretch = Stretch.None;
                        img57.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img57.Source = null;
                            }
                        }
                        img57.Tag = i.ToString();
                       // L.Add(57);
                        break;
                    case 58: img58.Stretch = Stretch.None;
                        img58.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img58.Source = null;
                            }
                        }
                        img58.Tag = i.ToString();
                      //  L.Add(58);
                        break;
                    case 59: img59.Stretch = Stretch.None;
                        img59.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img59.Source = null;
                            }
                        }
                        img59.Tag = i.ToString();
                       // L.Add(59);
                        break;
                    case 60: img60.Stretch = Stretch.None;
                        img60.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img60.Source = null;
                            }
                        }
                        img60.Tag = i.ToString();
                       // L.Add(60);
                        break;
                    case 61: img61.Stretch = Stretch.None;
                        img61.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img61.Source = null;
                            }
                        }
                        img61.Tag = i.ToString();
                       // L.Add(61);
                        break;
                    case 62: img62.Stretch = Stretch.None;
                        img62.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img62.Source = null;
                            }
                        }
                        img62.Tag = i.ToString();
                       // L.Add(62);
                        break;
                    case 63: img63.Stretch = Stretch.None;
                        img63.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img63.Source = null;
                            }
                        }
                        img63.Tag = i.ToString();
                       // L.Add(63);
                        break;
                    case 64: img64.Stretch = Stretch.None;
                        img64.Source = bpim1;
                        if (boly)
                        {
                            if (i == rem)
                            {
                                boly = false;
                                img64.Source = null;
                            }
                        }
                        img64.Tag = i.ToString();
                       // L.Add(64);
                       break;
                    default: break;
                }



            }
        }
        }

        private void R1_Checked(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(Simple));
        }

        private void R2_Checked(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(Medium));
        }
    }
}
