﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

using Windows.Graphics.Imaging;
using Windows.Storage;
using Windows.UI.Popups;
using Windows.Storage.Pickers;
using Windows.Storage.Streams;
using Windows.UI.Xaml.Media.Imaging;

// Pour en savoir plus sur le modèle d'élément Page vierge, consultez la page http://go.microsoft.com/fwlink/?LinkId=234238

namespace Your_Photo_is_a_puzzle
{
    /// <summary>
    /// Une page vide peut être utilisée seule ou constituer une page de destination au sein d'un frame.
    /// </summary>
    public sealed partial class Medium : Page
    {
        Random rand;
        List<int> L;
        BitmapDecoder decoder;
        public BitmapImage bmp;//= new BitmapImage();
        BitmapImage bpim1;
        InMemoryRandomAccessStream ras;
        BitmapEncoder enc;
        BitmapBounds bounds;
        uint N = 500;
        uint M = 125;

/************ Mes méthodes *************************************************************************************************/




        Boolean VerifExist(List<int> LL, int r)
        {
            for (int i = 0; i < LL.Count; i++)
            {
                if (LL[i] == r) return true;//l'element exist
            }
            return false;
        }

        async void IsWin()
        {
            if  (
                (
                ((String)img1.Tag == "1") &&
                ((String)img2.Tag == "2") &&
                ((String)img3.Tag == "3") &&
                ((String)img4.Tag == "4") &&
                ((String)img5.Tag == "5") &&
                ((String)img6.Tag == "6") &&
                ((String)img7.Tag == "7") &&
                ((String)img8.Tag == "8") &&
                ((String)img9.Tag == "9") &&
                ((String)img10.Tag == "10") &&
                ((String)img11.Tag == "11") &&
                ((String)img12.Tag == "12") &&
                ((String)img13.Tag == "13") &&
                ((String)img14.Tag == "14") &&
                ((String)img15.Tag == "15") 
                )
                )
            {
                // Create a MessageDialog
                var messageDialog = new MessageDialog("You won, Congratulations.");
                messageDialog.Title = "Winning";
                // Or create a separate callback for different commands
                messageDialog.Commands.Add(new UICommand(
                    "OK", new UICommandInvokedHandler(this.CommandInvokedHandler1)));
                // Set CommandIndex. 0 means default.
                messageDialog.DefaultCommandIndex = 0;
                // Show MessageDialog
                await messageDialog.ShowAsync();
            }
        }

        private void CommandInvokedHandler1(IUICommand command)
        {
            // Do something here on the command handler
        }

        private void Img1_Click(object sender, RoutedEventArgs e)
        {
            if (img1.Source != null)
            {
                if (img2.Source == null)
                {
                    img2.Source = img1.Source;
                    img2.Tag = img1.Tag;
                    img1.Source = null;
                    IsWin();
                }
                if (img5.Source == null)
                {
                    img5.Source = img1.Source;
                    img5.Tag = img1.Tag;
                    img1.Source = null;
                    IsWin();
                }
            }
        }

        private void Img2_Click(object sender, RoutedEventArgs e)
        {
            if (img2.Source != null)
            {
                if (img1.Source == null)
                {
                    img1.Source = img2.Source;
                    img1.Tag = img2.Tag;
                    img2.Source = null;
                    IsWin();
                }
                if (img6.Source == null)
                {
                    img6.Source = img2.Source;
                    img6.Tag = img2.Tag;
                    img2.Source = null;
                    IsWin();
                }
                if (img3.Source == null)
                {
                    img3.Source = img2.Source;
                    img3.Tag = img2.Tag;
                    img2.Source = null;
                    IsWin();
                }
            }
        }
        private void Img3_Click(object sender, RoutedEventArgs e)
        {
            if (img3.Source != null)
            {
                if (img2.Source == null)
                {
                    img2.Source = img3.Source;
                    img2.Tag = img3.Tag;
                    img3.Source = null;
                    IsWin();
                }
                if (img7.Source == null)
                {
                    img7.Source = img3.Source;
                    img7.Tag = img3.Tag;
                    img3.Source = null;
                    IsWin();
                }
                if (img4.Source == null)
                {
                    img4.Source = img3.Source;
                    img4.Tag = img3.Tag;
                    img3.Source = null;
                    IsWin();
                }
            }
        }

        private void Img4_Click(object sender, RoutedEventArgs e)
        {
            if (img4.Source != null)
            {
                if (img3.Source == null)
                {
                    img3.Source = img4.Source;
                    img3.Tag = img4.Tag;
                    img4.Source = null;
                    IsWin();
                }
                if (img8.Source == null)
                {
                    img8.Source = img4.Source;
                    img8.Tag = img4.Tag;
                    img4.Source = null;
                    IsWin();
                }
            }
        }

        private void Img5_Click(object sender, RoutedEventArgs e)
        {
            if (img5.Source != null)
            {
                if (img1.Source == null)
                {
                    img1.Source = img5.Source;
                    img1.Tag = img5.Tag;
                    img5.Source = null;
                    IsWin();
                }
                if (img6.Source == null)
                {
                    img6.Source = img5.Source;
                    img6.Tag = img5.Tag;
                    img5.Source = null;
                    IsWin();
                }
                if (img9.Source == null)
                {
                    img9.Source = img5.Source;
                    img9.Tag = img5.Tag;
                    img5.Source = null;
                    IsWin();
                }
            }
        }

        private void Img6_Click(object sender, RoutedEventArgs e)
        {
            if (img6.Source != null)
            {
                if (img2.Source == null)
                {
                    img2.Source = img6.Source;
                    img2.Tag = img6.Tag;
                    img6.Source = null;
                    IsWin();
                }
                if (img5.Source == null)
                {
                    img5.Source = img6.Source;
                    img5.Tag = img6.Tag;
                    img6.Source = null;
                    IsWin();
                }
                if (img7.Source == null)
                {
                    img7.Source = img6.Source;
                    img7.Tag = img6.Tag;
                    img6.Source = null;
                    IsWin();
                }
                if (img10.Source == null)
                {
                    img10.Source = img6.Source;
                    img10.Tag = img6.Tag;
                    img6.Source = null;
                    IsWin();
                }
            }
        }

        private void Img7_Click(object sender, RoutedEventArgs e)
        {
            if (img7.Source != null)
            {
                if (img6.Source == null)
                {
                    img6.Source = img7.Source;
                    img6.Tag = img7.Tag;
                    img7.Source = null;
                    IsWin();
                }
                if (img3.Source == null)
                {
                    img3.Source = img7.Source;
                    img3.Tag = img7.Tag;
                    img7.Source = null;
                    IsWin();
                }
                if (img8.Source == null)
                {
                    img8.Source = img7.Source;
                    img8.Tag = img7.Tag;
                    img7.Source = null;
                    IsWin();
                }
                if (img11.Source == null)
                {
                    img11.Source = img7.Source;
                    img11.Tag = img7.Tag;
                    img7.Source = null;
                    IsWin();
                }
            }
        }

        private void Img8_Click(object sender, RoutedEventArgs e)
        {
            if (img8.Source != null)
            {
                if (img7.Source == null)
                {
                    img7.Source = img8.Source;
                    img7.Tag = img8.Tag;
                    img8.Source = null;
                    IsWin();
                }
                if (img4.Source == null)
                {
                    img4.Source = img8.Source;
                    img4.Tag = img8.Tag;
                    img8.Source = null;
                    IsWin();
                }
                if (img12.Source == null)
                {
                    img12.Source = img8.Source;
                    img12.Tag = img8.Tag;
                    img8.Source = null;
                    IsWin();
                }
            }
        }

        private void Img9_Click(object sender, RoutedEventArgs e)
        {
            if (img9.Source != null)
            {
                if (img5.Source == null)
                {
                    img5.Source = img9.Source;
                    img5.Tag = img9.Tag;
                    img9.Source = null;
                    IsWin();
                }
                if (img10.Source == null)
                {
                    img10.Source = img9.Source;
                    img10.Tag = img9.Tag;
                    img9.Source = null;
                    IsWin();
                }
                if (img13.Source == null)
                {
                    img13.Source = img9.Source;
                    img13.Tag = img9.Tag;
                    img9.Source = null;
                    IsWin();
                }
            }
        }

        private void Img10_Click(object sender, RoutedEventArgs e)
        {
            if (img10.Source != null)
            {
                if (img6.Source == null)
                {
                    img6.Source = img10.Source;
                    img6.Tag = img10.Tag;
                    img10.Source = null;
                    IsWin();
                }
                if (img9.Source == null)
                {
                    img9.Source = img10.Source;
                    img9.Tag = img10.Tag;
                    img10.Source = null;
                    IsWin();
                }
                if (img14.Source == null)
                {
                    img14.Source = img10.Source;
                    img14.Tag = img10.Tag;
                    img10.Source = null;
                    IsWin();
                }
                if (img11.Source == null)
                {
                    img11.Source = img10.Source;
                    img11.Tag = img10.Tag;
                    img10.Source = null;
                    IsWin();
                }
            }
        }

        private void Img11_Click(object sender, RoutedEventArgs e)
        {
            if (img11.Source != null)
            {
                if (img7.Source == null)
                {
                    img7.Source = img11.Source;
                    img7.Tag = img11.Tag;
                    img11.Source = null;
                    IsWin();
                }
                if (img10.Source == null)
                {
                    img10.Source = img11.Source;
                    img10.Tag = img11.Tag;
                    img11.Source = null;
                    IsWin();
                }
                if (img15.Source == null)
                {
                    img15.Source = img11.Source;
                    img15.Tag = img11.Tag;
                    img11.Source = null;
                    IsWin();
                }
                if (img12.Source == null)
                {
                    img12.Source = img11.Source;
                    img12.Tag = img11.Tag;
                    img11.Source = null;
                    IsWin();
                }
            }
        }

        private void Img12_Click(object sender, RoutedEventArgs e)
        {
            if (img12.Source != null)
            {
                if (img8.Source == null)
                {
                    img8.Source = img12.Source;
                    img8.Tag = img12.Tag;
                    img12.Source = null;
                    IsWin();
                }
                if (img11.Source == null)
                {
                    img11.Source = img12.Source;
                    img11.Tag = img12.Tag;
                    img12.Source = null;
                    IsWin();
                }
                if (img16.Source == null)
                {
                    img16.Source = img12.Source;
                    img16.Tag = img12.Tag;
                    img12.Source = null;
                    IsWin();
                }
            }
        }

        private void Img13_Click(object sender, RoutedEventArgs e)
        {
            if (img13.Source != null)
            {
                if (img9.Source == null)
                {
                    img9.Source = img13.Source;
                    img9.Tag = img13.Tag;
                    img13.Source = null;
                    IsWin();
                }
                if (img14.Source == null)
                {
                    img14.Source = img13.Source;
                    img14.Tag = img13.Tag;
                    img13.Source = null;
                    IsWin();
                }
            }
        }

        private void Img14_Click(object sender, RoutedEventArgs e)
        {
            if (img14.Source != null)
            {
                if (img13.Source == null)
                {
                    img13.Source = img14.Source;
                    img13.Tag = img14.Tag;
                    img14.Source = null;
                    IsWin();
                }
                if (img10.Source == null)
                {
                    img10.Source = img14.Source;
                    img10.Tag = img14.Tag;
                    img14.Source = null;
                    IsWin();
                }
                if (img15.Source == null)
                {
                    img15.Source = img14.Source;
                    img15.Tag = img14.Tag;
                    img14.Source = null;
                    IsWin();
                }
            }
        }
        private void Img15_Click(object sender, RoutedEventArgs e)
        {
            if (img15.Source != null)
            {
                if (img14.Source == null)
                {
                    img14.Source = img15.Source;
                    img14.Tag = img15.Tag;
                    img15.Source = null;
                    IsWin();
                }
                if (img11.Source == null)
                {
                    img11.Source = img15.Source;
                    img11.Tag = img15.Tag;
                    img15.Source = null;
                    IsWin();
                }
                if (img16.Source == null)
                {
                    img16.Source = img15.Source;
                    img16.Tag = img15.Tag;
                    img15.Source = null;
                    IsWin();
                }
            }
        }

        private void Img16_Click(object sender, RoutedEventArgs e)
        {
            if (img16.Source != null)
            {
                if (img15.Source == null)
                {
                    img15.Source = img16.Source;
                    img15.Tag = img16.Tag;
                    img16.Source = null;
                    IsWin();
                }
                if (img12.Source == null)
                {
                    img12.Source = img16.Source;
                    img12.Tag = img16.Tag;
                    img16.Source = null;
                    IsWin();
                }
            }
        }
        uint X0 = 0;
        uint Y0 = 0;
/*****************************************************************************************************************************/
        public Medium()
        {
            this.InitializeComponent();
            R2.IsChecked = true;
            img1.Tapped += Img1_Click;
            img2.Tapped += Img2_Click;
            img3.Tapped += Img3_Click;
            img4.Tapped += Img4_Click;
            img5.Tapped += Img5_Click;
            img6.Tapped += Img6_Click;
            img7.Tapped += Img7_Click;
            img8.Tapped += Img8_Click;
            img9.Tapped += Img9_Click;
            img10.Tapped += Img10_Click;
            img11.Tapped += Img11_Click;
            img12.Tapped += Img12_Click;
            img13.Tapped += Img13_Click;
            img14.Tapped += Img14_Click;
            img15.Tapped += Img15_Click;
            img16.Tapped += Img16_Click;
            
        }

        int rem;
        Boolean boly ;
        async private void Button_Click(object sender, RoutedEventArgs e)
        {
            boly = true;
            //img1.Source = null;
            rand = new Random();
            rem = 16;
            L = new List<int>();
            //ouvrir un fileDialogue
            FileOpenPicker openPicker = new FileOpenPicker();
            openPicker.ViewMode = PickerViewMode.Thumbnail;
            openPicker.SuggestedStartLocation = PickerLocationId.PicturesLibrary;
            openPicker.FileTypeFilter.Add(".jpg");
            openPicker.FileTypeFilter.Add(".jpeg");
            openPicker.FileTypeFilter.Add(".bmp");
            openPicker.FileTypeFilter.Add(".png");
            StorageFile imgFile = await openPicker.PickSingleFileAsync();

            //////////////////////////////////////////////////////////////
            if (imgFile != null)
            {
                // Ensure the stream is disposed once the image is loaded
                using (IRandomAccessStream fileStream = await imgFile.OpenAsync(Windows.Storage.FileAccessMode.Read))
                {
                    bmp = new BitmapImage();

                   // bmp.DecodePixelType = DecodePixelType.Physical;
                    bmp.DecodePixelHeight = (int)N;
                    bmp.DecodePixelWidth = (int)N;
                   

                    await bmp.SetSourceAsync(fileStream);
                    img0.Source = bmp;

                }


                /*********************************************************************************************************/
                var filestream = await imgFile.OpenAsync(Windows.Storage.FileAccessMode.Read);
                decoder = await BitmapDecoder.CreateAsync(filestream);

                

                for (int i = 1; i <= 16; i++)
                {
                    ras = null;
                    enc = null;
                    bpim1 = null;

                    switch (i)
                    {
                        case 1: X0 = 0; Y0 = 0; break;
                        case 2: X0 = 125; Y0 = 0; break;
                        case 3: X0 = 251; Y0 = 0; break;
                        case 4: X0 = 375; Y0 = 0; break;
                        case 5: X0 = 0; Y0 = 125; break;
                        case 6: X0 = 125; Y0 = 125; break;
                        case 7: X0 = 251; Y0 = 125; break;
                        case 8: X0 = 375; Y0 = 125; break;
                        case 9: X0 = 0; Y0 = 251; break;
                        case 10: X0 = 125; Y0 = 251; break;
                        case 11: X0 = 251; Y0 = 251; break;
                        case 12: X0 = 375; Y0 = 251; break;
                        case 13: X0 = 0; Y0 = 375; break;
                        case 14: X0 = 125; Y0 = 375; break;
                        case 15: X0 = 251; Y0 = 375; break;
                        case 16: X0 = 375; Y0 = 375; break;
                        default: break;
                    }

                    ras = new InMemoryRandomAccessStream();
                    enc = await BitmapEncoder.CreateForTranscodingAsync(ras, decoder);

                    enc.BitmapTransform.ScaledWidth = N;
                    enc.BitmapTransform.ScaledHeight = N;

                    bounds = new BitmapBounds();
                    bounds.Height = M;
                    bounds.Width = M;
                    bounds.X = X0;
                    bounds.Y = Y0;

                    enc.BitmapTransform.Bounds = bounds;

                    try
                    {
                        await enc.FlushAsync();
                    }
                    catch (Exception)
                    {

                        throw;
                    }

                    bpim1 = new BitmapImage();
                    bpim1.SetSource(ras);

                    int r = rand.Next(1, 17);

                   /* while ((VerifExist(L, r) == true) || (r == 17))
                    {
                        r = rand.Next(1, 17);
                    }*/

                    if (i == 1)
                    {
                        while (r == 17)
                        {
                            rand = new Random();
                            r = rand.Next(1, 17);
                        }
                        L.Add(r);
                    }
                    else
                    {
                        while ((VerifExist(L, r) == true) || (r == 17))
                        {
                            rand = new Random();
                            r = rand.Next(1, 17);
                        }
                        L.Add(r);
                    }

                    switch (r)
                    {
                        case 1: img1.Stretch = Stretch.None;
                            img1.Source = bpim1;
                            if(boly)
                            {
                                if(i==rem)
                                {
                                    boly = false;
                                    img1.Source = null;
                                }
                            }
                            img1.Tag = i.ToString();
                            break;
                        case 2: img2.Stretch = Stretch.None;
                            img2.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img2.Source = null;
                                }
                            }
                            img2.Tag = i.ToString();
                            break;
                        case 3: img3.Stretch = Stretch.None;
                            img3.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img3.Source = null;
                                }
                            }
                            img3.Tag = i.ToString();
                            break;
                        case 4: img4.Stretch = Stretch.None;
                            img4.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img4.Source = null;
                                }
                            }
                            img4.Tag = i.ToString();
                            break;
                        case 5: img5.Stretch = Stretch.None;
                            img5.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img5.Source = null;
                                }
                            }
                            img5.Tag = i.ToString();
                            break;
                        case 6: img6.Stretch = Stretch.None;
                            img6.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img6.Source = null;
                                }
                            }
                            img6.Tag = i.ToString();
                            break;
                        case 7: img7.Stretch = Stretch.None;
                            img7.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img7.Source = null;
                                }
                            }
                            img7.Tag = i.ToString();
                            break;
                        case 8: img8.Stretch = Stretch.None;
                            img8.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img8.Source = null;
                                }
                            }
                            img8.Tag = i.ToString();
                            break;
                        case 9: img9.Stretch = Stretch.None;
                            img9.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img9.Source = null;
                                }
                            }
                            img9.Tag = i.ToString();
                            break;
                        case 10: img10.Stretch = Stretch.None;
                            img10.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img10.Source = null;
                                }
                            }
                            img10.Tag = i.ToString();
                            break;
                        case 11: img11.Stretch = Stretch.None;
                            img11.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img11.Source = null;
                                }
                            }
                            img11.Tag = i.ToString();
                            break;
                        case 12: img12.Stretch = Stretch.None;
                            img12.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img12.Source = null;
                                }
                            }
                            img12.Tag = i.ToString();
                            break;
                        case 13: img13.Stretch = Stretch.None;
                            img13.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img13.Source = null;
                                }
                            }
                            img13.Tag = i.ToString();
                            break;
                        case 14: img14.Stretch = Stretch.None;
                            img14.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img14.Source = null;
                                }
                            }
                            img14.Tag = i.ToString();
                            break;
                        case 15: img15.Stretch = Stretch.None;
                            img15.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img15.Source = null;
                                }
                            }
                            img15.Tag = i.ToString();
                            break;
                        case 16: img16.Stretch = Stretch.None;
                            img16.Source = bpim1;
                            if (boly)
                            {
                                if (i == rem)
                                {
                                    boly = false;
                                    img16.Source = null;
                                }
                            }
                            img16.Tag = i.ToString();
                            break;

                        default: break;
                    }



                }
            }
        }

        private void R2_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void R1_Checked(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(Simple));
        }

        private void R3_Checked(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(Hard));
        }
    }
}
